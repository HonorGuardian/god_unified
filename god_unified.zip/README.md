# G.O.D. v2.2 - Unified System

A visual-interactive architecture (React + Tailwind + Lucide).

## Run locally

```bash
npm install
npm run dev
```

## Deploy on Vercel

1. Push to GitHub
2. Import repo to Vercel
3. Deploy (defaults auto-detect Vite)